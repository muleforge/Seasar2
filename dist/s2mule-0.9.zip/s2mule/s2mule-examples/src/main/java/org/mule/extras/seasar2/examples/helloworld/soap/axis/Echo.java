package org.mule.extras.seasar2.examples.helloworld.soap.axis;

public interface Echo {
	
	String echo(String echo);
	
}
