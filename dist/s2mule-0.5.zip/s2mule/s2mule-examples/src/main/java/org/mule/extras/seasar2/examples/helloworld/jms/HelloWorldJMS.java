package org.mule.extras.seasar2.examples.helloworld.jms;

import org.mule.extras.seasar2.sender.S2MuleSender;
import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;
import org.seasar.framework.exception.ResourceNotFoundRuntimeException;

public class HelloWorldJMS {

	private static final String CONFIGURE_PATH = "helloworld-jms.dicon";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// create a Seasar2 container using the configuration file
			S2Container container = S2ContainerFactory.create(CONFIGURE_PATH);
			
			// get instance of "greetingClient" from the container
			S2MuleSender sender = (S2MuleSender) container.getComponent(S2MuleSender.class);
			
			// output the message
			sender.dispatch("Hello World!");
			System.out.println("The message is sent successfully.");
			
		} catch (ResourceNotFoundRuntimeException e){
			System.out.println("Config file can not be resolved: " + CONFIGURE_PATH);
		}
	}
}
